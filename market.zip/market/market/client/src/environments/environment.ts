
export const environment = {
  HTTPS: true,
  production: false
};

