const database = {
    database: 'mongodb://localhost:27017/authentication',
    secret: 'yoursecret',
};

module.exports = database