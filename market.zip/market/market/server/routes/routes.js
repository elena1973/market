const express = require('express');
const router = express.Router();
const handlers = require('../handlers/handlers')
const adminHandlers = require('../handlers/admin')
const marketHandlers = require('../handlers/webmarket')
const cartHandlers = require('../handlers/cart')


router.get('/market', handlers.verifyToken, (req, res) => {
    handlers.webmarket(req, res)
});

router.get('/allproductsadmin', (req, res) => {
    adminHandlers.allProductsAdmin(req, res)
});

router.get('/admin', (req, res) => {
    adminHandlers.admin(req, res)
});

router.post('/addProducts', (req, res) => {
    adminHandlers.addProducts(req, res)
})

router.post('/updateproduct', (req, res) => {
    adminHandlers.updateProduct(req, res)
})

router.post('/register', (req, res) => {
    handlers.register(req, res)
})

router.get('/checkID/:id/:email', (req, res) => {
    handlers.checkID(req, res)
})


router.post('/login', (req, res) => {
    handlers.login(req, res)
});


router.get('/info', (req, res) => {
    webmarketHandlers.info(req, res)
})


router.get('/allproducts', (req, res) => {
    webmarketHandlers.allProducts(req, res)
})


router.post('/cartisopen', (req, res) => {
    cartHandlers.cartIsOpen(req, res)
})

router.post('/createcart', (req, res) => {
    cartHandlers.createCart(req, res)
})

router.post('/addtocart', (req, res) => {
    cartHandlers.addToCart(req, res)
})

router.get('/cartsdetails/:id', (req, res) => {
    cartHandlers.cartDetails(req, res)
})

router.delete('/removeitem/:id/:cartID', (req, res) => {
    cartHandlers.removeItem(req, res)
})

router.delete('/dropcart/:id/:cartID', (req, res) => {
    cartHandlers.dropCart(req, res)
})

router.get('/getuser/:id', (req, res) => {
    marketHandlers.getuser(req, res)
})

router.get('/checkShipDate/:date', (req, res) => {
    marketHandlers.checkShipDate(req, res)
})

router.post('/check-out', (req, res) => {
    marketHandlers.checkOut(req, res)
})

router.get('/save/:id', (req, res) => {
    console.log(req.params)
    console.log(req.body)
    marketHandlers.save(req, res)
})

module.exports = router;